﻿namespace MyExpenses
{
    public interface IInterface
    {
        string GetPlatformRoot();

        void Landscape();
        void Portrait();
    }
}