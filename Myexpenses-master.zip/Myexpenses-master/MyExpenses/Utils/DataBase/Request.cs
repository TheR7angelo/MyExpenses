﻿namespace MyExpenses.Utils.Database;

public static partial class SqLite
{
    #region Set

    public static void RefreshImage()
    {
        FillImages();
    }

    #endregion
}