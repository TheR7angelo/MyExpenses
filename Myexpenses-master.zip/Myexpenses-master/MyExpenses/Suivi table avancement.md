﻿# Gestion des tables

- [ ] abonnement (en cours)
- [x] categorie
- [ ] credit
- [x] historique
- [x] portefeuille (compte dans le fichier xlsx)
- [x] lieu
- [ ] tickets
- [x] type compte
- [x] type payement
- [ ] type récurence (en cours)

6/10 == 60%