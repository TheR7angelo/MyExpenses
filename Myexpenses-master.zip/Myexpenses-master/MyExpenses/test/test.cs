﻿
namespace MyExpenses.test;

public static class Test
{

}