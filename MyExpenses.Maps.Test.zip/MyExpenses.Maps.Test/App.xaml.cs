﻿namespace MyExpenses.Maps.Test;

public partial class App
{

}